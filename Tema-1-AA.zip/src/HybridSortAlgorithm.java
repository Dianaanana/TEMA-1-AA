public class HybridSortAlgorithm implements Run{

    int[] arr;
    int size;

    public HybridSortAlgorithm(int[] arr, int size) {
        this.arr = arr;
        this.size = size;
    }

    @Override
    public void run() {
        TimSort.timSort(arr, size);
//        for (int i = 0; i < size; i++)
//        {
//            for(int j = i+1; j < size; j++)
//            {
//                if (arr[j] < arr[i])
//                {
//                    int temp = arr[i];
//                    arr[i] = arr[j];
//                    arr[j] = temp;
//                }
//            }
//        }
    }

    public int[] getArr() {
        return arr;
    }

    public void setArr(int[] arr) {
        this.arr = arr;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
