import java.io.IOException;


public class Main {


    public static void main(final String[] args) throws IOException {

        System.out.println("Testing TimSort ...");
        for(int i = 1; i <= Constants.NR_TESTS ; i++) {
            RWOp.createFiles(i);
            HybridSortAlgorithm myAlgorithm = RWOp.readInputs(Integer.parseInt(args[0]));

//            Instant start = Instant.now();
            long start1 = System.nanoTime();
            myAlgorithm.run();
//            Instant end = Instant.now();
            long end1 = System.nanoTime();
            System.out.println("start = " + start1 + "\nend = " + end1);
//            Duration duration = Duration.between(start, end);
//            System.out.println("Execution time test " + i + ": " + duration.toSeconds() + "s " + duration.toMillis() % 1000 + "ms " + duration.toNanos() % 1000000 + "ns");
            System.out.println("Elapsed Time in nano seconds: "+ (end1-start1));
            RWOp.writeOutputs(myAlgorithm);

        }

    }
}