public class Algorithms implements Run {


    @Override
    public void run() {

    }
}
