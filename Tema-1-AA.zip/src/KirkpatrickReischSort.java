public class KirkpatrickReischSort implements Run{


    @Override
    public void run() {

    }
}
