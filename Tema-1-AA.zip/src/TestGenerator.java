import java.io.IOException;
import java.util.Random;

public class TestGenerator {
    private static final Random RANDOM = new Random();

    private static void generateTest(TestParams params) throws IOException {
        // initialize array
        int[] array = new int[params.size];
        params.outWriter.write(params.size + "\n");

        for(int i = 0; i < params.size; i++) {
            array[i] = RANDOM.nextInt(1, 9999999);
            params.outWriter.write(array[i] + " ");
        }
        System.out.println(array);
        params.outWriter.write("\n");
        params.outWriter.close();
    }

    /**
     *
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws  IOException {
        final TestParams[] testParams = {
            new TestParams(1000, "src/in"),
            new TestParams(1500, "src/in"),
            new TestParams(2000, "src/in"),
            new TestParams(3000, "src/in"),
            new TestParams(4000, "src/in"),
            new TestParams(5000, "src/in"),
            new TestParams(10000, "src/in"),
            new TestParams(15000, "src/in"),
            new TestParams(30000, "src/in"),
            new TestParams(50000, "src/in"),

            new TestParams(10, "src/in"),
            new TestParams(15, "src/in"),
            new TestParams(20, "src/in"),
            new TestParams(30, "src/in"),
            new TestParams(40, "src/in"),
            new TestParams(50, "src/in"),
            new TestParams(100, "src/in"),
            new TestParams(150, "src/in"),
            new TestParams(300, "src/in"),
            new TestParams(500, "src/in"),

            new TestParams(10, "src/in"),
            new TestParams(15, "src/in"),
            new TestParams(20, "src/in"),
            new TestParams(30, "src/in"),
            new TestParams(40, "src/in"),
            new TestParams(50, "src/in"),
            new TestParams(100, "src/in"),
            new TestParams(150, "src/in"),
            new TestParams(300, "src/in"),
            new TestParams(500, "src/in"),
        };

        for(int i = 0; i < TestParams.testNumber; i++) {
            generateTest(testParams[i]);
        }
    }
}
