public class Constants {
    static final int NR_TESTS = 30;
    static final String INPUT_PATH = "in/";
    static final String OUPUT_PATH = "out/";
}
